let mapSort = require('./sort-map');

result.mapSort = mapSort;