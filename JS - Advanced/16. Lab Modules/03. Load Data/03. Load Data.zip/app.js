let sort = require('./data-funcs').sortProp;
let filter = require('./data-funcs').filterProp;

result.sort = sort;
result.filter = filter;