let Entity = require('./entity');
let Dog = require('./dog');
let Person = require('./person');
let Student = require('./student');

result.Entity = Entity;
result.Dog = Dog;
result.Person = Person;
result.Student = Student;